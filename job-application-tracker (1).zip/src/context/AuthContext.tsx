import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';
import { api, getStoredToken, getStoredUser, setStoredAuth, clearStoredAuth } from '../services/api';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (data: { name: string; email: string; password: string; college?: string; graduationYear?: string; branch?: string }) => Promise<void>;
  loginAsDemo: () => Promise<void>;
  updateProfile: (profileData: Partial<User>) => Promise<User>;
  logout: () => void;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(getStoredUser());
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    const initAuth = async () => {
      const token = getStoredToken();
      if (token) {
        try {
          const res = await api.getMe();
          setUser(res.user);
        } catch {
          // If token expired or invalid, auto-fallback to demo for preview seamlessness
          try {
            const demoRes = await api.demoLogin();
            setStoredAuth(demoRes.token, demoRes.user);
            setUser(demoRes.user);
          } catch {
            clearStoredAuth();
            setUser(null);
          }
        }
      } else {
        // Auto-login as demo student if first visit so user gets immediate full experience!
        try {
          const demoRes = await api.demoLogin();
          setStoredAuth(demoRes.token, demoRes.user);
          setUser(demoRes.user);
        } catch (e) {
          console.error('Demo auto-login failed:', e);
        }
      }
      setIsLoading(false);
    };

    initAuth();
  }, []);

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      const res = await api.login({ email, password });
      setStoredAuth(res.token, res.user);
      setUser(res.user);
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (data: { name: string; email: string; password: string; college?: string; graduationYear?: string; branch?: string }) => {
    setIsLoading(true);
    try {
      const res = await api.register(data);
      setStoredAuth(res.token, res.user);
      setUser(res.user);
    } finally {
      setIsLoading(false);
    }
  };

  const loginAsDemo = async () => {
    setIsLoading(true);
    try {
      const res = await api.demoLogin();
      setStoredAuth(res.token, res.user);
      setUser(res.user);
    } finally {
      setIsLoading(false);
    }
  };

  const updateProfile = async (profileData: Partial<User>): Promise<User> => {
    const res = await api.updateProfile(profileData);
    setUser(res.user);
    const token = getStoredToken();
    if (token) {
      setStoredAuth(token, res.user);
    }
    return res.user;
  };

  const logout = () => {
    clearStoredAuth();
    setUser(null);
  };

  const refreshUser = async () => {
    try {
      const res = await api.getMe();
      setUser(res.user);
    } catch {
      // ignore
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        register,
        loginAsDemo,
        updateProfile,
        logout,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
