import React, { useState, useEffect, useCallback } from 'react';
import { 
  Plus, 
  ListFilter, 
  Kanban, 
  CalendarDays, 
  BarChart3, 
  LayoutDashboard, 
  AlertCircle, 
  CheckCircle2, 
  Sparkles,
  RefreshCw,
  Search,
  IndianRupee,
  Briefcase
} from 'lucide-react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { api } from './services/api';
import { JobApplication, InterviewSchedule, DashboardStats, ApplicationStatus } from './types';
import { Navbar } from './components/Navbar';
import { DashboardStats as DashboardStatsComponent } from './components/DashboardStats';
import { UpcomingInterviews } from './components/UpcomingInterviews';
import { ApplicationsList } from './components/ApplicationsList';
import { KanbanBoard } from './components/KanbanBoard';
import { AnalyticsView } from './components/AnalyticsView';
import { ApplicationModal } from './components/ApplicationModal';
import { InterviewModal } from './components/InterviewModal';
import { AuthModal } from './components/AuthModal';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { ProfileView } from './components/ProfileView';
import { ProfileModal } from './components/ProfileModal';
import { ResumeManagementView } from './components/ResumeManagementView';

function MainTrackerApp() {
  const { user, isAuthenticated } = useAuth();
  
  // Navigation & View State
  const [activeTab, setActiveTab] = useState<'dashboard' | 'applications' | 'interviews' | 'resumes' | 'analytics' | 'profile'>('dashboard');
  const [applicationsViewMode, setApplicationsViewMode] = useState<'list' | 'kanban'>('list');

  // Data State
  const [applications, setApplications] = useState<JobApplication[]>([]);
  const [interviews, setInterviews] = useState<InterviewSchedule[]>([]);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Modal State
  const [isAppModalOpen, setIsAppModalOpen] = useState(false);
  const [editingApp, setEditingApp] = useState<JobApplication | null>(null);

  const [isInterviewModalOpen, setIsInterviewModalOpen] = useState(false);
  const [interviewTargetAppId, setInterviewTargetAppId] = useState<string | undefined>(undefined);
  const [editingInterview, setEditingInterview] = useState<InterviewSchedule | null>(null);

  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; company: string } | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Fetch all user data
  const fetchData = useCallback(async () => {
    if (!isAuthenticated) {
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const [appsRes, interviewsRes, statsRes] = await Promise.all([
        api.getApplications(),
        api.getInterviews(),
        api.getAnalytics(),
      ]);
      setApplications(appsRes.applications || []);
      setInterviews(interviewsRes.interviews || []);
      setStats(statsRes.stats || null);
    } catch (err: any) {
      console.error('Error loading tracker data:', err);
      showToast(err.message || 'Failed to fetch application data', 'error');
    } finally {
      setLoading(false);
    }
  }, [isAuthenticated]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Handlers for Applications
  const handleSaveApplication = async (appData: Partial<JobApplication>) => {
    try {
      if (editingApp) {
        const res = await api.updateApplication(editingApp.id, appData);
        showToast(`Updated application for ${res.application.company}!`);
      } else {
        const res = await api.createApplication(appData);
        showToast(`Added ${res.application.company} (${res.application.role}) to tracker!`);
      }
      await fetchData();
    } catch (err: any) {
      showToast(err.message || 'Failed to save application', 'error');
      throw err;
    }
  };

  const handleStatusChange = async (id: string, newStatus: ApplicationStatus) => {
    try {
      const res = await api.updateApplicationStatus(id, newStatus);
      showToast(`Status updated to "${newStatus}" for ${res.application.company}`);
      await fetchData();
    } catch (err: any) {
      showToast(err.message || 'Failed to update status', 'error');
    }
  };

  const handleDeleteConfirm = async () => {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      await api.deleteApplication(deleteTarget.id);
      showToast(`Removed application for ${deleteTarget.company}`);
      setDeleteTarget(null);
      await fetchData();
    } catch (err: any) {
      showToast(err.message || 'Failed to delete application', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  // Handlers for Interviews
  const handleSaveInterview = async (interviewData: any) => {
    try {
      const res = await api.scheduleInterview(interviewData);
      showToast(`Scheduled ${interviewData.roundType} for ${res.application.company}!`);
      await fetchData();
    } catch (err: any) {
      showToast(err.message || 'Failed to schedule interview', 'error');
      throw err;
    }
  };

  const handleDeleteInterview = async (applicationId: string) => {
    try {
      const res = await api.deleteInterview(applicationId);
      showToast(`Removed scheduled interview for ${res.application.company}`);
      await fetchData();
    } catch (err: any) {
      showToast(err.message || 'Failed to remove interview', 'error');
    }
  };

  // Reset demo dataset
  const handleResetData = async () => {
    try {
      await api.resetData();
      showToast('Sample placement dataset reloaded successfully!');
      await fetchData();
    } catch (err: any) {
      showToast(err.message || 'Failed to reset data', 'error');
    }
  };

  const openAddModal = () => {
    setEditingApp(null);
    setIsAppModalOpen(true);
  };

  const openEditModal = (app: JobApplication) => {
    setEditingApp(app);
    setIsAppModalOpen(true);
  };

  const openScheduleModal = (appId?: string) => {
    setEditingInterview(null);
    setInterviewTargetAppId(appId);
    setIsInterviewModalOpen(true);
  };

  const openEditInterviewModal = (interview: InterviewSchedule) => {
    setEditingInterview(interview);
    setInterviewTargetAppId(interview.applicationId);
    setIsInterviewModalOpen(true);
  };

  const handleFilterFromStats = (status: ApplicationStatus | 'All') => {
    setActiveTab('applications');
  };

  const upcomingInterviewsCount = interviews.filter(i => !i.completed && new Date(`${i.date}T${i.time || '23:59'}`) >= new Date()).length;

  return (
    <div className="min-h-screen bg-[#FCFCFA] text-[#1A1A1A] flex flex-col font-['Plus_Jakarta_Sans',sans-serif]">
      
      {/* Navigation Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAddModal={openAddModal}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        onOpenProfile={() => setIsProfileModalOpen(true)}
        applicationsCount={applications.length}
        upcomingInterviewsCount={upcomingInterviewsCount}
      />

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <div className={`flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-xl text-xs font-semibold ${
            toastMessage.type === 'success' 
              ? 'bg-[#1A1A1A] text-[#FCFCFA] border border-[#333333]' 
              : 'bg-rose-900 text-rose-50 border border-rose-800'
          }`}>
            {toastMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-300" />
            )}
            <span>{toastMessage.text}</span>
          </div>
        </div>
      )}

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6">
        
        {/* Loading Skeleton */}
        {loading && applications.length === 0 ? (
          <div className="space-y-6 animate-pulse">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="h-28 bg-white rounded-xl border border-[#E5E5E1]"></div>
              ))}
            </div>
            <div className="h-96 bg-white rounded-xl border border-[#E5E5E1]"></div>
          </div>
        ) : (
          <>
            {/* View 1: Dashboard Overview */}
            {activeTab === 'dashboard' && (
              <div className="space-y-6">
                
                {/* Editorial Welcome Header */}
                <div className="bg-[#1A1A1A] rounded-2xl p-6 sm:p-8 text-[#FCFCFA] shadow-sm border border-[#2C2C2C] flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden">
                  <div className="relative z-10 max-w-xl">
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#2C2C2C] text-[#D4D4D0] text-[10px] font-semibold uppercase tracking-widest border border-[#3E3E3E] mb-3">
                      <Sparkles className="w-3 h-3 text-amber-300" />
                      <span>Placement Ledger • Season 2026</span>
                    </div>
                    <h1 className="font-serif text-3xl sm:text-4xl font-normal tracking-tight text-[#FCFCFA] leading-tight">
                      Welcome, <span className="italic font-medium">{user?.name || 'Student'}</span>
                    </h1>
                    <p className="text-xs sm:text-sm text-[#A3A39E] mt-2 leading-relaxed">
                      You currently maintain <strong className="text-[#FCFCFA] font-medium">{applications.length} recorded application{applications.length === 1 ? '' : 's'}</strong>.
                      {upcomingInterviewsCount > 0 ? (
                        <span className="text-[#F0DFBE] ml-1 font-medium">
                          {upcomingInterviewsCount} interview round{upcomingInterviewsCount === 1 ? '' : 's'} pending this cycle.
                        </span>
                      ) : (
                        <span className="text-[#A3A39E] ml-1">
                          Track company drives, assessment stages, and placement offerings in one place.
                        </span>
                      )}
                    </p>
                  </div>

                  <div className="relative z-10 flex flex-wrap items-center gap-3">
                    <button
                      id="btn-dashboard-add-application"
                      onClick={openAddModal}
                      className="flex items-center gap-2 bg-[#FCFCFA] hover:bg-[#F0F0EC] active:bg-[#E5E5E1] text-[#1A1A1A] text-xs font-semibold px-4 py-2.5 rounded-lg shadow-none border border-[#FCFCFA] transition-all cursor-pointer"
                    >
                      <Plus className="w-4 h-4 stroke-[2.5]" />
                      <span>Add Placement Application</span>
                    </button>

                    <button
                      id="btn-dashboard-view-all"
                      onClick={() => setActiveTab('applications')}
                      className="flex items-center gap-2 bg-[#2C2C2C] hover:bg-[#383838] text-[#FCFCFA] text-xs font-medium px-4 py-2.5 rounded-lg border border-[#3E3E3E] transition-colors cursor-pointer"
                    >
                      <ListFilter className="w-4 h-4 text-[#A3A39E]" />
                      <span>View Applications ({applications.length})</span>
                    </button>

                    <button
                      id="btn-dashboard-resumes"
                      onClick={() => setActiveTab('resumes')}
                      className="flex items-center gap-2 bg-[#2C2C2C] hover:bg-[#383838] text-[#FCFCFA] text-xs font-medium px-4 py-2.5 rounded-lg border border-[#3E3E3E] transition-colors cursor-pointer"
                    >
                      <Sparkles className="w-4 h-4 text-amber-300" />
                      <span>Resume</span>
                    </button>
                  </div>
                </div>

                {/* Dashboard Stats */}
                <DashboardStatsComponent
                  stats={stats}
                  onFilterByStatus={handleFilterFromStats}
                  onOpenAddModal={openAddModal}
                />

                {/* Upcoming Interviews Imminent Section */}
                <UpcomingInterviews
                  interviews={interviews}
                  onOpenScheduleModal={openScheduleModal}
                  onEditInterview={openEditInterviewModal}
                  onDeleteInterview={handleDeleteInterview}
                />

              </div>
            )}

            {/* View 2: Applications Tracker (List & Kanban View) */}
            {activeTab === 'applications' && (
              <div className="space-y-5">
                
                {/* Header with View Mode Switcher */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 sm:p-5 rounded-2xl border border-[#E5E5E1] shadow-xs">
                  <div>
                    <h2 className="font-serif text-2xl font-semibold text-[#1A1A1A] tracking-tight">Applications Registry</h2>
                    <p className="text-xs text-[#737373] mt-0.5">
                      Review company placement logs, salaries, CTC tiers, and recruitment pipeline status
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* View Switcher: List vs Kanban */}
                    <div className="flex items-center bg-[#F0F0EC] p-1 rounded-lg border border-[#E5E5E1]">
                      <button
                        id="btn-view-list"
                        onClick={() => setApplicationsViewMode('list')}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                          applicationsViewMode === 'list'
                            ? 'bg-[#1A1A1A] text-[#FCFCFA] font-semibold shadow-xs'
                            : 'text-[#737373] hover:text-[#1A1A1A]'
                        }`}
                      >
                        <ListFilter className="w-3.5 h-3.5" />
                        <span>Grid / List</span>
                      </button>

                      <button
                        id="btn-view-kanban"
                        onClick={() => setApplicationsViewMode('kanban')}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                          applicationsViewMode === 'kanban'
                            ? 'bg-[#1A1A1A] text-[#FCFCFA] font-semibold shadow-xs'
                            : 'text-[#737373] hover:text-[#1A1A1A]'
                        }`}
                      >
                        <Kanban className="w-3.5 h-3.5" />
                        <span>Pipeline Kanban</span>
                      </button>
                    </div>

                    <button
                      id="btn-add-app-tracker-view"
                      onClick={openAddModal}
                      className="flex items-center gap-1.5 bg-[#1A1A1A] hover:bg-[#2C2C2C] text-[#FCFCFA] text-xs font-semibold px-3.5 py-2 rounded-lg border border-[#1A1A1A] shadow-xs transition-colors cursor-pointer"
                    >
                      <Plus className="w-4 h-4 stroke-[2.5]" />
                      <span>New Application</span>
                    </button>
                  </div>
                </div>

                {/* Content according to view mode */}
                {applicationsViewMode === 'list' ? (
                  <ApplicationsList
                    applications={applications}
                    onEdit={openEditModal}
                    onDelete={(id, company) => setDeleteTarget({ id, company })}
                    onScheduleInterview={openScheduleModal}
                    onStatusChange={handleStatusChange}
                    onOpenAddModal={openAddModal}
                  />
                ) : (
                  <KanbanBoard
                    applications={applications}
                    onStatusChange={handleStatusChange}
                    onEdit={openEditModal}
                    onScheduleInterview={openScheduleModal}
                    onOpenAddModal={openAddModal}
                  />
                )}

              </div>
            )}

            {/* View 3: Interviews Calendar & Schedules */}
            {activeTab === 'interviews' && (
              <UpcomingInterviews
                interviews={interviews}
                onOpenScheduleModal={openScheduleModal}
                onEditInterview={openEditInterviewModal}
                onDeleteInterview={handleDeleteInterview}
              />
            )}

            {/* View 4: Resume Management & AI Analyzer (Browser Only Storage) */}
            {activeTab === 'resumes' && (
              <ResumeManagementView
                showToast={showToast}
              />
            )}

            {/* View 5: Analytics & Insights */}
            {activeTab === 'analytics' && (
              <AnalyticsView
                applications={applications}
                stats={stats}
                onResetData={handleResetData}
              />
            )}

            {/* View 6: Full Student Profile & Badges */}
            {activeTab === 'profile' && (
              <ProfileView
                onOpenEditModal={() => setIsProfileModalOpen(true)}
              />
            )}
          </>
        )}

      </main>

      {/* Modals */}
      <ApplicationModal
        isOpen={isAppModalOpen}
        onClose={() => setIsAppModalOpen(false)}
        onSave={handleSaveApplication}
        initialData={editingApp}
      />

      <InterviewModal
        isOpen={isInterviewModalOpen}
        onClose={() => setIsInterviewModalOpen(false)}
        onSave={handleSaveInterview}
        applications={applications}
        initialApplicationId={interviewTargetAppId}
        initialInterview={editingInterview}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onSuccess={() => fetchData()}
      />

      <ProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        onSuccess={() => fetchData()}
      />

      <DeleteConfirmModal
        isOpen={!!deleteTarget}
        companyName={deleteTarget?.company || ''}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDeleteConfirm}
        isDeleting={isDeleting}
      />

      {/* Editorial Footer */}
      <footer className="mt-auto border-t border-[#E5E5E1] bg-[#FCFCFA] py-5 text-center text-xs text-[#737373]">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2 font-medium">
            <span className="w-2 h-2 rounded-full bg-[#1A1A1A]"></span>
            <span className="font-serif font-semibold text-[#1A1A1A]">JobTrack</span>
            <span className="text-[#A3A39E]">•</span>
            <span>Placement Application & Recruitment Ledger</span>
          </div>
          <div className="text-[11px] text-[#8C8C88]">
            Full-Stack Node/Express API Architecture & Local Persistence
          </div>
        </div>
      </footer>

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainTrackerApp />
    </AuthProvider>
  );
}
